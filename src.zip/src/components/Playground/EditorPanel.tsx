import React, { useEffect } from 'react';
import Editor, { useMonaco } from '@monaco-editor/react';
import styles from './Playground.module.css';

interface Props {
  code: string;
  onChange: (value: string) => void;
}

function registerAmpscript(monaco: any) {
  const LANG = 'ampscript';

  // Evita re-registro em hot reload
  if (monaco.languages.getLanguages().some((l: any) => l.id === LANG)) return;

  monaco.languages.register({ id: LANG });

  monaco.languages.setMonarchTokensProvider(LANG, {
    ignoreCase: true,
    tokenizer: {
      root: [
        // Bloco %%[ ... ]%%
        [/%%\[/, { token: 'delimiter.ampscript', next: '@ampBlock' }],
        // Inline %%=...=%%
        [/%%=/, { token: 'delimiter.ampscript', next: '@ampInline' }],
        // Personalization %%Nome%%
        [/%%[A-Za-z_][A-Za-z0-9_]*%%/, 'variable.other'],
        // Tags HTML
        [/<\/?[a-z][^>]*>/i, 'tag'],
        [/<!--/, { token: 'comment', next: '@htmlComment' }],
      ],

      ampBlock: [
        [/\]\s*%%/, { token: 'delimiter.ampscript', next: '@pop' }],
        { include: '@ampCommon' },
      ],

      ampInline: [
        [/=%%/, { token: 'delimiter.ampscript', next: '@pop' }],
        { include: '@ampCommon' },
      ],

      ampCommon: [
        // Comentário de bloco
        [/\/\*/, { token: 'comment', next: '@blockComment' }],
        // Palavras-chave
        [/\b(VAR|SET|IF|ELSEIF|ELSE|ENDIF|FOR|TO|DO|NEXT|STEP|THEN|AND|OR|NOT)\b/i, 'keyword'],
        // Booleanos e null
        [/\b(TRUE|FALSE|NULL)\b/i, 'constant.language'],
        // Variáveis @nome
        [/@[A-Za-z_][A-Za-z0-9_]*/, 'variable'],
        // Funções (identificador seguido de parêntese)
        [/[A-Za-z_][A-Za-z0-9_]*(?=\s*\()/, 'entity.name.function'],
        // Strings com aspas duplas
        [/"([^"\\]|\\.)*"/, 'string'],
        // Strings com aspas simples
        [/'([^'\\]|\\.)*'/, 'string'],
        // Números
        [/\b\d+(\.\d+)?\b/, 'number'],
        // Delimitadores
        [/[().,]/, 'delimiter'],
        // Operadores
        [/[+\-*/<>=!]+/, 'operator'],
        // Espaços
        [/\s+/, ''],
      ],

      blockComment: [
        [/\*\//, { token: 'comment', next: '@pop' }],
        [/./, 'comment'],
      ],

      htmlComment: [
        [/-->/, { token: 'comment', next: '@pop' }],
        [/./, 'comment'],
      ],
    },
  });

  monaco.editor.defineTheme('ampscript-dark', {
    base: 'vs-dark',
    inherit: true,
    rules: [
      { token: 'delimiter.ampscript', foreground: 'FFD700', fontStyle: 'bold' },
      { token: 'keyword',             foreground: '569CD6', fontStyle: 'bold' },
      { token: 'constant.language',   foreground: '569CD6' },
      { token: 'variable',            foreground: '9CDCFE' },
      { token: 'variable.other',      foreground: 'C586C0' },
      { token: 'entity.name.function',foreground: 'DCDCAA' },
      { token: 'string',              foreground: 'CE9178' },
      { token: 'number',              foreground: 'B5CEA8' },
      { token: 'comment',             foreground: '6A9955', fontStyle: 'italic' },
      { token: 'tag',                 foreground: '4EC9B0' },
      { token: 'operator',            foreground: 'D4D4D4' },
      { token: 'delimiter',           foreground: 'D4D4D4' },
    ],
    colors: {
      'editor.background':           '#1e1e1e',
      'editor.lineHighlightBackground': '#2a2a2a',
      'editorLineNumber.foreground': '#555555',
      'editorCursor.foreground':     '#FFD700',
    },
  });

  // Autocomplete básico com palavras-chave e funções
  monaco.languages.registerCompletionItemProvider(LANG, {
    provideCompletionItems(model: any, position: any) {
      const word = model.getWordUntilPosition(position);
      const range = {
        startLineNumber: position.lineNumber,
        endLineNumber:   position.lineNumber,
        startColumn:     word.startColumn,
        endColumn:       word.endColumn,
      };

      const keywords = [
        'VAR', 'SET', 'IF', 'ELSEIF', 'ELSE', 'ENDIF',
        'FOR', 'TO', 'DO', 'NEXT', 'STEP', 'THEN',
        'AND', 'OR', 'NOT', 'TRUE', 'FALSE', 'NULL',
      ];

      const functions = [
        // String
        'CONCAT', 'UPPERCASE', 'LOWERCASE', 'PROPERCASE',
        'TRIM', 'TRIMLEFT', 'TRIMRIGHT', 'LENGTH',
        'SUBSTRING', 'INDEXOF', 'REPLACE', 'REGEXMATCH', 'REGEXREPLACE',
        'CHAR', 'DOMAIN', 'FORMAT', 'FORMATCURRENCY', 'FORMATNUMBER',
        'URLENCODE', 'URLDECODE', 'STRINGTOHEX', 'WRAPTEXT',
        // Math
        'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'MOD',
        'ABS', 'CEILING', 'FLOOR', 'ROUND', 'SQRT', 'POWER',
        'RANDOM', 'MAX', 'MIN',
        // Date
        'NOW', 'GETSENDTIME', 'SYSTEMDATE', 'FORMATDATE',
        'DATEADD', 'DATEDIFF', 'DATEPART', 'DATEPARSE',
        'STRINGTODATE', 'LOCALDATETOSYSTEMDATE', 'SYSTEMDATETOLOCALDATE',
        // Utility
        'OUTPUT', 'OUTPUTLINE', 'V', 'EMPTY', 'ISNULL', 'ISNULLDEFAULT',
        'IIF', 'TOSTRING', 'NOT', 'ATTRIBUTEVALUE',
        'BASE64ENCODE', 'BASE64DECODE', 'MD5', 'SHA256', 'GUID',
        'RAISEERROR', 'TREATASCONTENT',
        // Data Extension
        'LOOKUP', 'LOOKUPROWS', 'LOOKUPORDEREDROWS', 'LOOKUPORDEREDROWSCS',
        'ROW', 'ROWCOUNT', 'FIELD', 'DATAEXTENSIONROWCOUNT',
        'INSERTDE', 'UPDATEDE', 'UPSERTDE', 'DELETEDE',
      ];

      const kwSuggestions = keywords.map(kw => ({
        label: kw,
        kind:  monaco.languages.CompletionItemKind.Keyword,
        insertText: kw,
        range,
      }));

      const fnSuggestions = functions.map(fn => ({
        label:      fn,
        kind:       monaco.languages.CompletionItemKind.Function,
        insertText: `${fn}($1)`,
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range,
      }));

      return { suggestions: [...kwSuggestions, ...fnSuggestions] };
    },
  });
}

export function EditorPanel({ code, onChange }: Props) {
  const monaco = useMonaco();

  useEffect(() => {
    if (monaco) registerAmpscript(monaco);
  }, [monaco]);

  return (
    <div className={styles.editorWrap}>
      <Editor
        height="100%"
        language="ampscript"
        theme="ampscript-dark"
        value={code}
        onChange={v => onChange(v ?? '')}
        options={{
          fontSize:              14,
          minimap:               { enabled: false },
          wordWrap:              'on',
          scrollBeyondLastLine:  false,
          tabSize:               2,
          lineNumbers:           'on',
          renderWhitespace:      'none',
          automaticLayout:       true,
          suggestOnTriggerCharacters: true,
          quickSuggestions:      true,
          folding:               true,
        }}
      />
    </div>
  );
}