import type { AmpValue, AmpRow, AmpRowset, EvalContext } from '../types';
import { toString, toNumber } from '../evaluator';

export const dataExtensionFunctions: Record<string, (args: AmpValue[], ctx: EvalContext) => AmpValue> = {

  // ─── Leitura ──────────────────────────────────────────────────────────────

  LOOKUP(args, ctx) {
    const deName   = toString(args[0]);
    const retField = toString(args[1]);
    const keyField = toString(args[2]);
    const keyValue = toString(args[3]);

    const de = findDE(ctx, deName);
    if (!de) return null;

    const row = de.rows.find(r =>
      toString(r[keyField]).toLowerCase() === keyValue.toLowerCase()
    );
    return row ? (row[retField] ?? null) : null;
  },

  LOOKUPROWS(args, ctx) {
    const deName   = toString(args[0]);
    const keyField = toString(args[1]);
    const keyValue = toString(args[2]);

    const de = findDE(ctx, deName);
    if (!de) return [];

    return de.rows.filter(r =>
      toString(r[keyField]).toLowerCase() === keyValue.toLowerCase()
    );
  },

  LOOKUPORDEREDROWS(args, ctx) {
    const deName   = toString(args[0]);
    const maxRows  = toNumber(args[1]);
    const orderBy  = toString(args[2]);
    const keyField = toString(args[3]);
    const keyValue = toString(args[4]);

    const de = findDE(ctx, deName);
    if (!de) return [];

    let rows = de.rows.filter(r =>
      toString(r[keyField]).toLowerCase() === keyValue.toLowerCase()
    );

    // Ordenação simples: "FieldName ASC" ou "FieldName DESC"
    const parts = orderBy.trim().split(/\s+/);
    const field = parts[0];
    const dir   = (parts[1] ?? 'ASC').toUpperCase();

    rows = rows.sort((a, b) => {
      const av = toString(a[field]);
      const bv = toString(b[field]);
      return dir === 'DESC' ? bv.localeCompare(av) : av.localeCompare(bv);
    });

    return maxRows > 0 ? rows.slice(0, maxRows) : rows;
  },

  LOOKUPORDEREDROWSCS(args, ctx) {
    // Versão case-sensitive — mesmo comportamento no playground
    return dataExtensionFunctions.LOOKUPORDEREDROWS(args, ctx);
  },

  // ─── Acesso a rowsets ─────────────────────────────────────────────────────

  ROW(args) {
    const rowset = args[0] as AmpRowset;
    const index  = toNumber(args[1]); // base 1
    if (!Array.isArray(rowset)) return null;
    return rowset[index - 1] ?? null;
  },

  ROWCOUNT(args) {
    const rowset = args[0];
    if (!Array.isArray(rowset)) return 0;
    return rowset.length;
  },

  FIELD(args) {
    const row   = args[0] as AmpRow;
    const field = toString(args[1]);
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    return row[field] ?? null;
  },

  DATAEXTENSIONROWCOUNT(args, ctx) {
    const deName = toString(args[0]);
    const de = findDE(ctx, deName);
    return de ? de.rows.length : 0;
  },

  // ─── Escrita ──────────────────────────────────────────────────────────────

  INSERTDE(args, ctx) {
    const deName = toString(args[0]);
    const de = findDE(ctx, deName);
    if (!de) return 0;

    const row: AmpRow = {};
    // Argumentos em pares: field, value, field, value...
    for (let i = 1; i < args.length - 1; i += 2) {
      const field = toString(args[i]);
      const value = args[i + 1] as string;
      row[field] = value;
    }
    de.rows.push(row);
    return 1;
  },

  UPDATEDE(args, ctx) {
    const deName   = toString(args[0]);
    const keyField = toString(args[1]);
    const keyValue = toString(args[2]);

    const de = findDE(ctx, deName);
    if (!de) return 0;

    let updated = 0;
    for (const row of de.rows) {
      if (toString(row[keyField]).toLowerCase() === keyValue.toLowerCase()) {
        for (let i = 3; i < args.length - 1; i += 2) {
          const field = toString(args[i]);
          const value = args[i + 1] as string;
          row[field] = value;
        }
        updated++;
      }
    }
    return updated;
  },

  UPSERTDE(args, ctx) {
    const deName   = toString(args[0]);
    const keyField = toString(args[1]);
    const keyValue = toString(args[2]);

    const de = findDE(ctx, deName);
    if (!de) return 0;

    const existing = de.rows.find(r =>
      toString(r[keyField]).toLowerCase() === keyValue.toLowerCase()
    );

    if (existing) {
      for (let i = 3; i < args.length - 1; i += 2) {
        existing[toString(args[i])] = args[i + 1] as string;
      }
    } else {
      const row: AmpRow = { [keyField]: keyValue };
      for (let i = 3; i < args.length - 1; i += 2) {
        row[toString(args[i])] = args[i + 1] as string;
      }
      de.rows.push(row);
    }
    return 1;
  },

  DELETEDE(args, ctx) {
    const deName   = toString(args[0]);
    const keyField = toString(args[1]);
    const keyValue = toString(args[2]);

    const de = findDE(ctx, deName);
    if (!de) return 0;

    const before = de.rows.length;
    de.rows = de.rows.filter(r =>
      toString(r[keyField]).toLowerCase() !== keyValue.toLowerCase()
    );
    return before - de.rows.length;
  },
};

// ─── Helper ───────────────────────────────────────────────────────────────────

function findDE(ctx: EvalContext, name: string) {
  return ctx.dataExtensions.find(
    de => de.name.toLowerCase() === name.toLowerCase()
  ) ?? null;
}
